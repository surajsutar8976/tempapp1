//import logo from './logo.svg';
import React from "react";
import Tempapp from "./components/Tempapp";
import './App.css';
import Head from "./components/Head";

function App() {
  return (
    <>
    <Head />
    <Tempapp />
    </>
  );
}

export default App;
