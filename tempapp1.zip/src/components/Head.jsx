import React from "react";

function Head() {
    return(

    <>
        <h2> Welcome to Temperature App</h2>
        <h5> Please Enter City Name to view Temparature</h5>
    </>);

}

export default Head;